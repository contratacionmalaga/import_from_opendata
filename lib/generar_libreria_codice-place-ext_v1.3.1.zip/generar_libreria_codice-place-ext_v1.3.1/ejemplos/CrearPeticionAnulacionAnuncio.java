package es.pruebas;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;

import org.dgpe.codice.common.caclib.PartyIdentificationType;
import org.dgpe.codice.common.cbclib.AgencyIDType;
import org.dgpe.codice.common.cbclib.DescriptionType;
import org.dgpe.codice.common.cbclib.IDType;
import org.dgpe.codice.common.cbclib.NoteType;

import ext.place.codice.common.caclib.AdditionalPublicationRequestType;
import ext.place.codice.common.caclib.NoticeCancellationType;
import ext.place.codice.common.caclib.UserType;
import ext.place.codice.common.cbclib.CancellationReasonCodeType;
import ext.place.codice.common.cbclib.UrgencyIndicatorType;
import ext.place.codice.maindoc.cancelnoticerequest.CancelNoticeRequestType;
import ext.place.codice.maindoc.cancelnoticerequest.ObjectFactory;

public class CrearPeticionAnulacionAnuncio {

  public static void main(String[] args) throws DatatypeConfigurationException, JAXBException {

    // Se crea el POJO con los datos de la petici�n de anulaci�n del anuncio
    CancelNoticeRequestType peticionAnunlacionAnuncio;
    peticionAnunlacionAnuncio = nuevaPeticionAnulacionAnuncio();

    // Se crea el objeto modelo que representa la petici�n de anulaci�n del anuncio
    ObjectFactory objFact = new ObjectFactory();
    JAXBElement<CancelNoticeRequestType> documento = objFact
        .createCancelNoticeRequest(peticionAnunlacionAnuncio);

    // Se realiza el marshall del objeto documento para generar el contenido XML
    JAXBContext jc = JAXBContext.newInstance(CancelNoticeRequestType.class);

    Marshaller marshaller = jc.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

    marshaller.marshal(documento, System.out);
    
  }

  private static CancelNoticeRequestType nuevaPeticionAnulacionAnuncio()
      throws DatatypeConfigurationException {

    CancelNoticeRequestType peticionAnulacionAnunio = new CancelNoticeRequestType();
    

    // Se a�ade el identificador de la petici�n
    // Ver apartado 3.3.1 de la Gu�a de Implementaci�n CODICE-PLACE-EXT  
    IDType id = new IDType();
    id.setValue("41421350");
    peticionAnulacionAnunio.setID(id);
    
    
    //Se a�ade el componente para indicar el ID del �rgano de contrataci�n al que
    // pertenece el expediente cuyo anuncio se ha anulado
    //Ver apartado 3.3.1 de la Gu�a de Implementaci�n CODICE-PLACE-EXT
    PartyIdentificationType contractingPartyIdentification = new PartyIdentificationType();
    IDType idParty = new IDType();
    idParty.setValue("10000380050768");
    id.setSchemeName("ID_PLATAFORMA");
    contractingPartyIdentification.setID(idParty);
    peticionAnulacionAnunio.setContractingPartyIdentification(contractingPartyIdentification);
    
    
    
    //Se a�ade el componente que contienen los detalles de la anulaci�n del anuncio.
    //Ver apartado 3.3.1 de la Gu�a de Implementaci�n CODICE-PLACE-EXT
    NoticeCancellationType noticeCancellation = new NoticeCancellationType();
    
    IDType idReference = new IDType();
    idReference.setValue("404210017");
    noticeCancellation.setReferencedID(idReference);
    
    CancellationReasonCodeType cancellationReasonCode = new CancellationReasonCodeType();
    cancellationReasonCode.setListURI("http://contrataciondelestado.es/codice/cl/2.02/CancellationReasonCode-2.02.gc");
    cancellationReasonCode.setListVersionID("2.02");
    cancellationReasonCode.setValue("1");
    noticeCancellation.setCancellationReasonCode(cancellationReasonCode);
    
    DescriptionType description = new DescriptionType();
    description.setValue("Error no subsanable en los pliegos. La licitaci�n se volver� a publicar");
    noticeCancellation.setDescription(description);
        
    peticionAnulacionAnunio.setNoticeCancellation(noticeCancellation);
    
    
    //Se a�ade el componente AdditionalPublicationRequest
    //Ver apartado 3.3.1 de la Gu�a de Implementaci�n CODICE-PLACE-EXT
    AdditionalPublicationRequestType additionalPublicationRequest = new AdditionalPublicationRequestType();
    
    AgencyIDType agencyId = new AgencyIDType();
    agencyId.setValue("BOE");
    additionalPublicationRequest.setAgencyID(agencyId);
    
    UrgencyIndicatorType urgencyIndicator = new UrgencyIndicatorType();
    urgencyIndicator.setValue(false);
    additionalPublicationRequest.setUrgencyIndicator(urgencyIndicator);
    
    NoteType note = new NoteType();
    note.setValue("Por error no subsanable se anula el anuncio de licitaci�n publicado el XX bla bla bla");
    additionalPublicationRequest.setNote(note);
    
    peticionAnulacionAnunio.getAdditionalPublicationRequest().add(additionalPublicationRequest);
    

    //Se a�ade el componente que contiene el identificador del usuario que realiza la petici�n
    //Ver apartado 3.3.1 de la Gu�a de Implementaci�n CODICE-PLACE-EXT
    UserType user = new UserType();
    IDType userId = new IDType();
    userId.setValue("00000000T");
    user.setUserID(userId);
    
    peticionAnulacionAnunio.setUser(user);
    
     
    return peticionAnulacionAnunio;
  }

 

}
