package es.pruebas;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;

import org.dgpe.codice.common.caclib.BudgetAmountType;
import org.dgpe.codice.common.caclib.ContractingPartyType;
import org.dgpe.codice.common.caclib.PartyIdentificationType;
import org.dgpe.codice.common.caclib.PartyNameType;
import org.dgpe.codice.common.caclib.PartyType;
import org.dgpe.codice.common.caclib.ProcurementProjectType;
import org.dgpe.codice.common.caclib.TenderingProcessType;
import org.dgpe.codice.common.caclib.TenderingTermsType;
import org.dgpe.codice.common.cbclib.ActivityCodeType;
import org.dgpe.codice.common.cbclib.BuyerProfileURIIDType;
import org.dgpe.codice.common.cbclib.ContractFolderIDType;
import org.dgpe.codice.common.cbclib.ContractingPartyTypeCodeType;
import org.dgpe.codice.common.cbclib.CustomizationIDType;
import org.dgpe.codice.common.cbclib.EstimatedOverallContractAmountType;
import org.dgpe.codice.common.cbclib.ExpenseCodeType;
import org.dgpe.codice.common.cbclib.IDType;
import org.dgpe.codice.common.cbclib.IssueDateType;
import org.dgpe.codice.common.cbclib.IssueTimeType;
import org.dgpe.codice.common.cbclib.NameType;
import org.dgpe.codice.common.cbclib.ProcedureCodeType;
import org.dgpe.codice.common.cbclib.ProfileIDType;
import org.dgpe.codice.common.cbclib.RequiredCurriculaIndicatorType;
import org.dgpe.codice.common.cbclib.SubmissionMethodCodeType;
import org.dgpe.codice.common.cbclib.TaxExclusiveAmountType;
import org.dgpe.codice.common.cbclib.TotalAmountType;
import org.dgpe.codice.common.cbclib.TypeCodeType;
import org.dgpe.codice.common.cbclib.UBLVersionIDType;
import org.dgpe.codice.common.cbclib.UUIDType;
import org.dgpe.codice.common.cbclib.UrgencyCodeType;
import org.dgpe.codice.common.cbclib.VariantConstraintIndicatorType;
import org.dgpe.codice.common.cbclib.WebsiteURIType;
import org.dgpe.codice.maindoc.pin.ObjectFactory;
import org.dgpe.codice.maindoc.pin.PriorInformationNoticeType;
import org.oasis.ubl.codelist.currencycode.CurrencyCodeContentType;

public class CrearAnuncioInformacionPrevia {

  public static void main(String[] args) throws DatatypeConfigurationException, JAXBException {

    // Se crea el POJO con los datos del anuncio de informaci�n previa
    PriorInformationNoticeType anuncioInformacionPrevia;
    anuncioInformacionPrevia = nuevoAnuncioInformacionPrevia();

    // Se crea el objeto modelo que representa el anuncio de informaci�n previa
    ObjectFactory objFact = new ObjectFactory();
    JAXBElement<PriorInformationNoticeType> documento = objFact
        .createPriorInformationNotice(anuncioInformacionPrevia);

    // Se realiza el marshall del objeto documento para generar el contenido XML
    JAXBContext jc = JAXBContext.newInstance(PriorInformationNoticeType.class);

    Marshaller marshaller = jc.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

    marshaller.marshal(documento, System.out);
    // marshaller.marshal(documento, new
    // File(propiedades.getProperty("fichero.salida")));

  }

  private static PriorInformationNoticeType nuevoAnuncioInformacionPrevia()
      throws DatatypeConfigurationException {

    PriorInformationNoticeType anuncioInformacionPrevia = new PriorInformationNoticeType();
    GregorianCalendar cal = new GregorianCalendar();

    // Se a�aden metadatos del documento.
    // Ver apartado 3.2.1 de la Gu�a de Implementaci�n CODICE

    UBLVersionIDType ublVersion = new UBLVersionIDType();
    ublVersion.setValue("2.1");
    anuncioInformacionPrevia.setUBLVersionID(ublVersion);

    CustomizationIDType customizationId = new CustomizationIDType();
    customizationId.setValue("CODICE 2.06");
    anuncioInformacionPrevia.setCustomizationID(customizationId);

    ProfileIDType profileId = new ProfileIDType();
    profileId.setValue("CiP 1.13");
    anuncioInformacionPrevia.setProfileID(profileId);

    IDType id = new IDType();
    id.setValue("0000001857095");
    anuncioInformacionPrevia.setID(id);

    UUIDType uuid = new UUIDType();
    uuid.setValue("2015-209563");
    anuncioInformacionPrevia.setUUID(uuid);

    ContractFolderIDType contractFolder = new ContractFolderIDType();
    contractFolder.setValue("16A032");
    anuncioInformacionPrevia.setContractFolderID(contractFolder);

    IssueDateType issueDate = new IssueDateType();
    cal.setTime(new Date());
    issueDate.setValue(DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED));
    anuncioInformacionPrevia.setIssueDate(issueDate);

    IssueTimeType issueTime = new IssueTimeType();
    cal.setTime(new Date());
    issueTime.setValue(DatatypeFactory.newInstance().newXMLGregorianCalendarTime(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND), DatatypeConstants.FIELD_UNDEFINED));
    anuncioInformacionPrevia.setIssueTime(issueTime);

    // Se a�aden elementos del anuncio de informaci�n previa
    anuncioInformacionPrevia.setContractingParty(crearContractingParty());
    anuncioInformacionPrevia.setTenderingTerms(crearTenderingTerms());
    anuncioInformacionPrevia.setTenderingProcess(crearTenderingProcess());
    anuncioInformacionPrevia.setProcurementProject(crearProcurementProject());

    return anuncioInformacionPrevia;
  }

  private static ContractingPartyType crearContractingParty() {
    // El ContractingParty es un tipo de interviniente.
    // Ver apartado 3.2.2 de la Gu�a de Implementaci�n CODICE

    ContractingPartyType contractingParty = new ContractingPartyType();

    ContractingPartyTypeCodeType contractingPartyTypeCode = new ContractingPartyTypeCodeType();
    contractingPartyTypeCode.setLanguageID("es");
    contractingPartyTypeCode
        .setListURI("http://contrataciondelestado.es/codice/cl/1.04/ContractingAuthorityCode-1.04.gc");
    contractingPartyTypeCode.setListVersionID("2006");
    contractingPartyTypeCode.setName("Administraci�n General del Estado");
    contractingPartyTypeCode.setValue("1");
    contractingParty.setContractingPartyTypeCode(contractingPartyTypeCode);

    ActivityCodeType activityCode = new ActivityCodeType();
    activityCode.setLanguageID("es");
    activityCode
        .setListURI("http://contrataciondelestado.es/codice/cl/1.04/ContractingAuthorityActivityCode-1.04.gc");
    activityCode.setListVersionID("2006");
    activityCode.setName("Investigaci�n, Desarrollo e Innovaci�n");
    activityCode.setValue("20");
    contractingParty.getActivityCode().add(activityCode);

    BuyerProfileURIIDType buyerProfile = new BuyerProfileURIIDType();
    buyerProfile
        .setValue("https://contrataciondelestado.es/wps/poc?uri=deeplink:perfilContratante&idBp=l7DZXv9D30s%3D");
    contractingParty.setBuyerProfileURIID(buyerProfile);

    contractingParty.setParty(crearParty());

    return contractingParty;
  }

  private static PartyType crearParty() {
    PartyType party = new PartyType();

    WebsiteURIType webSite = new WebsiteURIType();
    webSite.setValue("http://www.ieo.es");
    party.setWebsiteURI(webSite);

    PartyIdentificationType partyIdentification = new PartyIdentificationType();
    IDType id = new IDType();
    id.setSchemeName("ID_PLATAFORMA");
    id.setValue("10000430050802");
    partyIdentification.setID(id);
    party.getPartyIdentification().add(partyIdentification);

    PartyIdentificationType partyIdentification2 = new PartyIdentificationType();
    IDType id2 = new IDType();
    id2.setSchemeName("NIF");
    id2.setValue("Q2823001I");
    partyIdentification2.setID(id2);
    party.getPartyIdentification().add(partyIdentification2);

    PartyNameType partyName = new PartyNameType();
    NameType name = new NameType();
    name.setValue("Direcci�n del Instituto Espa�ol de Oceanograf�a");
    partyName.setName(name);
    party.getPartyName().add(partyName);

    return party;
  }

  private static TenderingTermsType crearTenderingTerms() {
    TenderingTermsType tenderingTerms = new TenderingTermsType();

    RequiredCurriculaIndicatorType requiredCurricula = new RequiredCurriculaIndicatorType();
    requiredCurricula.setValue(false);
    tenderingTerms.setRequiredCurriculaIndicator(requiredCurricula);

    VariantConstraintIndicatorType variantConstraint = new VariantConstraintIndicatorType();
    variantConstraint.setValue(false);
    tenderingTerms.setVariantConstraintIndicator(variantConstraint);

    return tenderingTerms;

  }

  private static TenderingProcessType crearTenderingProcess() {
    TenderingProcessType tenderingProcess = new TenderingProcessType();

    ProcedureCodeType procedureCode = new ProcedureCodeType();
    procedureCode.setLanguageID("es");
    procedureCode
        .setListURI("http://contrataciondelestado.es/codice/cl/2.05/TenderingProcessCode-2.05.gc");
    procedureCode.setListVersionID("2.05");
    procedureCode.setName("Abierto");
    procedureCode.setValue("1");
    tenderingProcess.setProcedureCode(procedureCode);

    UrgencyCodeType urgencyCode = new UrgencyCodeType();
    urgencyCode.setLanguageID("es");
    urgencyCode
        .setListURI("http://contrataciondelestado.es/codice/cl/1.04/DiligenceTypeCode-1.04.gc");
    urgencyCode.setListVersionID("2006");
    urgencyCode.setName("Ordinaria");
    urgencyCode.setValue("1");
    tenderingProcess.setUrgencyCode(urgencyCode);

    ExpenseCodeType expenseCode = new ExpenseCodeType();
    expenseCode.setLanguageID("es");
    expenseCode
        .setListURI("http://contrataciondelestado.es/codice/cl/1.04/ExpenseTypeCode-1.04.gc");
    expenseCode.setListVersionID("2006");
    expenseCode.setName("Anticipada");
    expenseCode.setValue("2");
    tenderingProcess.setExpenseCode(expenseCode);

    SubmissionMethodCodeType submissionMethod = new SubmissionMethodCodeType();
    submissionMethod.setLanguageID("es");
    submissionMethod
        .setListURI("http://contrataciondelestado.es/codice/cl/1.04/TenderDeliveryCode-1.04.gc");
    submissionMethod.setListVersionID("2006");
    submissionMethod.setName("Manual");
    submissionMethod.setValue("2");
    tenderingProcess.setSubmissionMethodCode(submissionMethod);

    return tenderingProcess;

  }

  private static ProcurementProjectType crearProcurementProject() {
    ProcurementProjectType procurementProject = new ProcurementProjectType();

    NameType name = new NameType();
    name.setValue("Servicio mantenimiento y suministro componentes boya oc�ano meteorol�gica Augusto Gonz�lez Linares.");
    procurementProject.getName().add(name);

    TypeCodeType typeCode = new TypeCodeType();
    typeCode.setLanguageID("es");
    typeCode.setListURI("http://contrataciondelestado.es/codice/cl/2.02/ContractCode-2.02.gc");
    typeCode.setListVersionID("2.02");
    typeCode.setName("Servicios");
    typeCode.setValue("2");
    procurementProject.setTypeCode(typeCode);

    BudgetAmountType budgetAmount = new BudgetAmountType();
    EstimatedOverallContractAmountType estimated = new EstimatedOverallContractAmountType();
    estimated.setCurrencyID(CurrencyCodeContentType.EUR.toString());
    estimated.setValue(new BigDecimal("404960"));
    budgetAmount.setEstimatedOverallContractAmount(estimated);
    TotalAmountType total = new TotalAmountType();
    total.setCurrencyID(CurrencyCodeContentType.EUR.toString());
    total.setValue(new BigDecimal("245000.8"));
    budgetAmount.setTotalAmount(total);
    TaxExclusiveAmountType taxExclusived = new TaxExclusiveAmountType();
    taxExclusived.setCurrencyID(CurrencyCodeContentType.EUR.toString());
    taxExclusived.setValue(new BigDecimal(202480));
    budgetAmount.setTaxExclusiveAmount(taxExclusived);

    procurementProject.setBudgetAmount(budgetAmount);

    return procurementProject;
  }

}
